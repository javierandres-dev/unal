import view.Form;

/**
 *
 * @author Johanna Zuluaga, Javier Andrés Garzón Patarroyo
 */
public class Main {

    public static void main(String[] args) {
        Form window = new Form();
        window.show();
    }
}
