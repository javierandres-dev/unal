-- drop schema db_meat;
create schema db_meat;
use db_meat;
CREATE TABLE carnes(id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, nombre VARCHAR(20) NOT NULL, cantidad VARCHAR(20) NOT NULL, animal VARCHAR(20) NOT NULL, peludo VARCHAR(20) NOT NULL);
select * from carnes;